﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO.Ports;

namespace Revenge_HMI
{
    public partial class Form1 : Form
    {
        bool mouseDown;
        private Point offset;
        string serialDataIn;
        sbyte indexofA, indexofB, indexofC, indexofD, indexofE, indexofF, indexofG, indexofH, indexofI, indexofJ, indexofK;

        public Form1()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            string[] portList = SerialPort.GetPortNames();
            comboBoxPuertos.Items.AddRange(portList);
            comboBoxBaudio.Text = "9600";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.compassneedle;
        }


        private void buttonMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void buttonMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
            Application.Exit();
        }

        private void panelTopMenu_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - offset.X, currentScreenPos.Y - offset.Y);
            }
        }

        private void panelTopMenu_MouseDown(object sender, MouseEventArgs e)
        {
            offset.X = e.X;
            offset.Y = e.Y;
            mouseDown = true;
        }

        private void panelTopMenu_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int angle;

            // Intenta convertir el valor de la TextBox a un número entero
            if (int.TryParse(textBox1.Text, out angle))
            {
                // Rotación de la imagen
                Bitmap bmp = new Bitmap(Properties.Resources.compassneedle);
                Graphics g = Graphics.FromImage(bmp);
                g.TranslateTransform((float)bmp.Width / 2, (float)bmp.Height / 2);
                g.RotateTransform(angle);
                g.TranslateTransform(-(float)bmp.Width / 2, -(float)bmp.Height / 2);
                pictureBox5.Image = bmp;
            }
        }
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            serialDataIn = serialPort1.ReadLine();
            this.BeginInvoke(new EventHandler(ShowData));

        }
        string data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, data11;
        private void ShowData(object sender, EventArgs e)
        {
            try
            {
                indexofA = Convert.ToSByte(serialDataIn.IndexOf("A"));
                indexofB = Convert.ToSByte(serialDataIn.IndexOf("B"));
                indexofC = Convert.ToSByte(serialDataIn.IndexOf("C"));
                indexofD = Convert.ToSByte(serialDataIn.IndexOf("D"));
                indexofE = Convert.ToSByte(serialDataIn.IndexOf("E"));
                indexofF = Convert.ToSByte(serialDataIn.IndexOf("F"));
                indexofG = Convert.ToSByte(serialDataIn.IndexOf("G"));
                indexofH = Convert.ToSByte(serialDataIn.IndexOf("H"));
                indexofI = Convert.ToSByte(serialDataIn.IndexOf("I"));
                indexofJ = Convert.ToSByte(serialDataIn.IndexOf("J"));
                indexofK = Convert.ToSByte(serialDataIn.IndexOf("K"));

                data1 = serialDataIn.Substring(0, indexofA);
                data2 = serialDataIn.Substring(indexofA + 1, (indexofB - indexofA) - 1);
                data3 = serialDataIn.Substring(indexofB + 1, (indexofC - indexofB) - 1);
                data4 = serialDataIn.Substring(indexofC + 1, (indexofD - indexofC) - 1);
                data5 = serialDataIn.Substring(indexofD + 1, (indexofE - indexofD) - 1);
                data6 = serialDataIn.Substring(indexofE + 1, (indexofF - indexofE) - 1);
                data7 = serialDataIn.Substring(indexofF + 1, (indexofG - indexofF) - 1);
                data8 = serialDataIn.Substring(indexofG + 1, (indexofH - indexofG) - 1);
                data9 = serialDataIn.Substring(indexofH + 1, (indexofI - indexofH) - 1);
                data10 = serialDataIn.Substring(indexofI + 1, (indexofJ - indexofI) - 1);
                data11 = serialDataIn.Substring(indexofJ + 1, (indexofK - indexofJ) - 1);

                chart2.Series["Altitud"].Points.AddY(Convert.ToDecimal(data5));
                chart1.Series["Velocidad"].Points.AddY(Convert.ToDecimal(data8));
                labelLatitud.Text = data7;
                labelLongitude.Text = data8;
                //labelReleaseAltitude.Text = data9;
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }

        }
    }
}
